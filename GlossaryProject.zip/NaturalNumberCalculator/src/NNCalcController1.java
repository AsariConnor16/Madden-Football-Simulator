import components.naturalnumber.NaturalNumber;
import components.naturalnumber.NaturalNumber2;

/**
 * Controller class.
 *
 * @author Connor Asari
 */
public final class NNCalcController1 implements NNCalcController {

    /**
     * Model object.
     */
    private final NNCalcModel model;

    /**
     * View object.
     */
    private final NNCalcView view;

    /**
     * Useful constants.
     */
    private static final NaturalNumber TWO = new NaturalNumber2(2),
            INT_LIMIT = new NaturalNumber2(Integer.MAX_VALUE);

    /**
     * Updates this.view to display this.model, and to allow only operations
     * that are legal given this.model.
     *
     * @param model
     *            the model
     * @param view
     *            the view
     * @ensures [view has been updated to be consistent with model]
     */
    private static void updateViewToMatchModel(NNCalcModel model, NNCalcView view) {

        NaturalNumber top = model.top();
        NaturalNumber bottom = model.bottom();

        view.updateTopDisplay(top);
        view.updateBottomDisplay(bottom);

        //Subtraction is allowed if top is greater than or equal to bottom
        boolean subtractAllowed = top.compareTo(bottom) >= 0;
        view.updateSubtractAllowed(subtractAllowed);

        //Division is allowed if the bottom is not 0
        NaturalNumber zero = bottom.newInstance();
        boolean divideAllowed = bottom.compareTo(zero) != 0;
        view.updateDivideAllowed(divideAllowed);

        //Power is allowed if bottom is less than or equal to int_limit
        boolean powerAllowed = bottom.compareTo(INT_LIMIT) <= 0;
        view.updatePowerAllowed(powerAllowed);

        //Root is allowed if the bottom is greater than or equal to 2
        //AND bottom is less than or equal to int_limit
        boolean rootAllowed = bottom.compareTo(TWO) >= 0
                && bottom.compareTo(INT_LIMIT) <= 0;
        view.updateRootAllowed(rootAllowed);
    }

    /**
     * Constructor.
     *
     * @param model
     *            model to connect to
     * @param view
     *            view to connect to
     */
    public NNCalcController1(NNCalcModel model, NNCalcView view) {
        this.model = model;
        this.view = view;
        updateViewToMatchModel(model, view);
    }

    @Override
    public void processClearEvent() {
        /*
         * Get alias to bottom from model
         */
        NaturalNumber bottom = this.model.bottom();
        /*
         * Update model in response to this event
         */
        bottom.clear();
        /*
         * Update view to reflect changes in model
         */
        updateViewToMatchModel(this.model, this.view);
    }

    @Override
    public void processSwapEvent() {
        /*
         * Get aliases to top and bottom from model
         */
        NaturalNumber top = this.model.top();
        NaturalNumber bottom = this.model.bottom();
        /*
         * Update model in response to this event
         */
        NaturalNumber temp = top.newInstance();
        temp.transferFrom(top);
        top.transferFrom(bottom);
        bottom.transferFrom(temp);
        /*
         * Update view to reflect changes in model
         */
        updateViewToMatchModel(this.model, this.view);
    }

    @Override
    public void processEnterEvent() {
        NaturalNumber top = this.model.top();
        NaturalNumber bottom = this.model.bottom();

        top.copyFrom(bottom);

        updateViewToMatchModel(this.model, this.view);
    }

    @Override
    public void processAddEvent() {
        NaturalNumber top = this.model.top();
        NaturalNumber bottom = this.model.bottom();

        //Compute top+bottom
        top.add(bottom);
        //Make bottom show the result, and clear top
        bottom.transferFrom(top);

        updateViewToMatchModel(this.model, this.view);
    }

    @Override
    public void processSubtractEvent() {
        NaturalNumber top = this.model.top();
        NaturalNumber bottom = this.model.bottom();

        //Compute top-bottom
        top.subtract(bottom);
        //Make bottom show the result, and clear top
        bottom.transferFrom(top);

        updateViewToMatchModel(this.model, this.view);
    }

    @Override
    public void processMultiplyEvent() {
        NaturalNumber top = this.model.top();
        NaturalNumber bottom = this.model.bottom();

        //Compute top*bottom
        top.multiply(bottom);
        //Make bottom show the result, clear top
        bottom.transferFrom(top);

        updateViewToMatchModel(this.model, this.view);
    }

    @Override
    public void processDivideEvent() {
        NaturalNumber top = this.model.top();
        NaturalNumber bottom = this.model.bottom();

        //Compute top/bottom, store the remainder
        NaturalNumber remainder = top.divide(bottom);
        //Make bottom show the quotient
        bottom.transferFrom(top);
        //Make top show the remainder
        top.transferFrom(remainder);

        updateViewToMatchModel(this.model, this.view);
    }

    @Override
    public void processPowerEvent() {
        NaturalNumber top = this.model.top();
        NaturalNumber bottom = this.model.bottom();

        //Compute top^bottom
        top.power(bottom.toInt());
        //Make bottom show the result, clear top
        bottom.transferFrom(top);

        updateViewToMatchModel(this.model, this.view);
    }

    @Override
    public void processRootEvent() {
        NaturalNumber top = this.model.top();
        NaturalNumber bottom = this.model.bottom();

        //Compute the bottom-th root of top
        top.root(bottom.toInt());
        //Make bottom show the result, clear top
        bottom.transferFrom(top);

        updateViewToMatchModel(this.model, this.view);
    }

    @Override
    public void processAddNewDigitEvent(int digit) {
        NaturalNumber bottom = this.model.bottom();

        bottom.multiplyBy10(digit);

        updateViewToMatchModel(this.model, this.view);
    }

}
